<?php 
	if (!($this->session->userdata('loggedin'))){
		redirect("Home/login");
	}
 ?>
<?php include 'partials/headern.php' ?>
<h1>dashboard</h1>

<li><a href="<?php echo base_url('index.php/Login/logoutUser'); ?>">Logout</a></li>


<?php include 'partials/footer.php' ?>