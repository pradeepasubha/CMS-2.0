<?php include 'partials/header.php' ?>

<br><br><br>



<?php echo form_open('Register/registerUser'); ?>


<div style="margin-left: 250px; border: 2px;" class="form-horizontal">
  <h1 style="margin-left: 113px; margin-bottom: 40px;">Register</h1>
  <div style="margin-left: 220px;">
  	<?php echo validation_errors(); ?>
  	<div style="color: green;">
  	<?php if ($this->session->flashdata('msg')) {
  		echo "<h3>".$this->session->flashdata('msg')."</h3>";
  	}
  	 ?></div>
  </div>

  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">User Name</label>
    <div class="col-sm-10">
      <input style="width: 60%; " type="text" class="form-control" id="inputEmail3" placeholder="User Name" name="uname">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">First Name</label>
    <div class="col-sm-10">
      <input style="width: 60%; " type="text" class="form-control" id="inputEmail3" placeholder="First Name" name="fname">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Last Name</label>
    <div class="col-sm-10">
      <input style="width: 60%; " type="text" class="form-control" id="inputEmail3" placeholder="Last Name" name="lname">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input style="width: 60%; " type="email" class="form-control" id="inputEmail3" placeholder="Email" name="email">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Birth Day</label>
    <div class="col-sm-10">
      <input style="width: 60%; " type="text" class="form-control" id="inputEmail3" placeholder="Birth Day" name="bday">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Addres</label>
    <div class="col-sm-10">
      <input style="width: 60%; " type="text" class="form-control" id="inputEmail3" placeholder="Addres" name="address">
    </div>
  </div>
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Phon Number</label>
    <div class="col-sm-10">
      <input style="width: 60%; " type="text" class="form-control" id="inputEmail3" placeholder="Phon Number" name="pnum">
    </div>
  </div>
  <div style="margin-top: 20px;" class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
    <div class="col-sm-10">
      <input style="width: 60%;" type="password" class="form-control" id="inputPassword3" placeholder="Password" name="password">
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" class="btn btn-default">Sign in</button>
    </div>
  </div>
</div>
<?php echo form_close(); ?>


<?php include 'partials/footer.php' ?>